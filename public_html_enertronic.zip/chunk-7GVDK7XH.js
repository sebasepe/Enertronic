import{a as Mt,d as Et,f as Ae,g as Pe,h as St}from"./chunk-3FH4NIEF.js";import{b as Ct,c as xt}from"./chunk-WMFON2VX.js";import{a as wt,b as M,c as he,d as Tt,e as It,f as ue,g as At,h as Pt,i as G,j as Rt,k as Ft,l as Dt,m as Nt,n as fe,o as ge,p as _e,q as be,r as ve,s as ye,t as Q}from"./chunk-CHQ27ST3.js";import{A as ut,C as gt,D as _t,F as bt,c as lt,d as ce,f as we,j as ct,k as dt,m as U,n as mt,p as j,q as pt,r as Te,v as Ie,w as me,y as pe,z as ht}from"./chunk-UBCMIPIA.js";import{A as yt,B as Ot,C as kt,h as ot,m as rt,u as de,v as st,x as ft,y as A,z as vt}from"./chunk-7HJOAY6B.js";import{$a as Qe,$b as le,Ab as C,Bb as a,C as qe,Cb as o,Db as y,Hb as et,Ib as ae,Jb as v,L as Se,Lb as I,M as Oe,Mb as oe,N as H,Nb as q,Ob as tt,Pb as re,Qb as P,Rb as R,Sa as Ye,T as Ue,U as S,Ua as s,Vb as it,W as w,Xb as k,Y as h,Yb as nt,Zb as c,_b as p,ab as W,ba as je,bc as Y,ca as Ge,da as L,ea as X,ec as d,fa as Ke,fc as m,g as E,hb as T,i as ze,ib as O,ja as V,jb as ie,ka as J,lc as at,mb as Ze,o as Me,oa as ee,pb as ne,ra as We,rc as se,sa as te,t as He,tc as x,ub as F,uc as ke,va as B,vb as _,w as $,wb as b,x as Ee,xb as $e,yb as Xe,zb as Je}from"./chunk-Y2QW5OYF.js";var Xt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275cmp=T({type:n,selectors:[["ng-component"]],hostAttrs:["cdk-text-field-style-loader",""],decls:0,vars:0,template:function(t,i){},styles:[`textarea.cdk-textarea-autosize {
  resize: none;
}

textarea.cdk-textarea-autosize-measuring {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: auto !important;
  overflow: hidden !important;
}

textarea.cdk-textarea-autosize-measuring-firefox {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: 0 !important;
}

@keyframes cdk-text-field-autofill-start { /*!*/ }
@keyframes cdk-text-field-autofill-end { /*!*/ }
.cdk-text-field-autofill-monitored:-webkit-autofill {
  animation: cdk-text-field-autofill-start 0s 1ms;
}

.cdk-text-field-autofill-monitored:not(:-webkit-autofill) {
  animation: cdk-text-field-autofill-end 0s 1ms;
}
`],encapsulation:2,changeDetection:0})}return n})(),Jt={passive:!0},Lt=(()=>{class n{_platform=h(ce);_ngZone=h(J);_renderer=h(Qe).createRenderer(null,null);_styleLoader=h(de);_monitoredElements=new Map;constructor(){}monitor(e){if(!this._platform.isBrowser)return ze;this._styleLoader.load(Xt);let t=we(e),i=this._monitoredElements.get(t);if(i)return i.subject;let l=new E,u="cdk-text-field-autofilled",f=N=>{N.animationName==="cdk-text-field-autofill-start"&&!t.classList.contains(u)?(t.classList.add(u),this._ngZone.run(()=>l.next({target:N.target,isAutofilled:!0}))):N.animationName==="cdk-text-field-autofill-end"&&t.classList.contains(u)&&(t.classList.remove(u),this._ngZone.run(()=>l.next({target:N.target,isAutofilled:!1})))},g=this._ngZone.runOutsideAngular(()=>(t.classList.add("cdk-text-field-autofill-monitored"),this._renderer.listen(t,"animationstart",f,Jt)));return this._monitoredElements.set(t,{subject:l,unlisten:g}),l}stopMonitoring(e){let t=we(e),i=this._monitoredElements.get(t);i&&(i.unlisten(),i.subject.complete(),t.classList.remove("cdk-text-field-autofill-monitored"),t.classList.remove("cdk-text-field-autofilled"),this._monitoredElements.delete(t))}ngOnDestroy(){this._monitoredElements.forEach((e,t)=>this.stopMonitoring(t))}static \u0275fac=function(t){return new(t||n)};static \u0275prov=Ue({token:n,factory:n.\u0275fac,providedIn:"root"})}return n})();var Vt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({})}return n})();var Bt=new w("MAT_INPUT_VALUE_ACCESSOR");var z=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({imports:[ct,Q,A]})}return n})();var ni=["button","checkbox","file","hidden","image","radio","range","reset","submit"],ai=new w("MAT_INPUT_CONFIG"),zt=(()=>{class n{_elementRef=h(B);_platform=h(ce);ngControl=h(he,{optional:!0,self:!0});_autofillMonitor=h(Lt);_ngZone=h(J);_formField=h(ye,{optional:!0});_renderer=h(W);_uid=h(j).getId("mat-input-");_previousNativeValue;_inputValueAccessor;_signalBasedValueAccessor;_previousPlaceholder=null;_errorStateTracker;_config=h(ai,{optional:!0});_cleanupIosKeyup;_cleanupWebkitWheel;_isServer=!1;_isNativeSelect=!1;_isTextarea=!1;_isInFormField=!1;focused=!1;stateChanges=new E;controlType="mat-input";autofilled=!1;get disabled(){return this._disabled}set disabled(e){this._disabled=pe(e),this.focused&&(this.focused=!1,this.stateChanges.next())}_disabled=!1;get id(){return this._id}set id(e){this._id=e||this._uid}_id;placeholder;name;get required(){return this._required??this.ngControl?.control?.hasValidator(M.required)??!1}set required(e){this._required=pe(e)}_required;get type(){return this._type}set type(e){this._type=e||"text",this._validateType(),!this._isTextarea&&Ie().has(this._type)&&(this._elementRef.nativeElement.type=this._type)}_type="text";get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}userAriaDescribedBy;get value(){return this._signalBasedValueAccessor?this._signalBasedValueAccessor.value():this._inputValueAccessor.value}set value(e){e!==this.value&&(this._signalBasedValueAccessor?this._signalBasedValueAccessor.value.set(e):this._inputValueAccessor.value=e,this.stateChanges.next())}get readonly(){return this._readonly}set readonly(e){this._readonly=pe(e)}_readonly=!1;disabledInteractive;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}_neverEmptyInputTypes=["date","datetime","datetime-local","month","time","week"].filter(e=>Ie().has(e));constructor(){let e=h(ue,{optional:!0}),t=h(G,{optional:!0}),i=h(fe),l=h(Bt,{optional:!0,self:!0}),u=this._elementRef.nativeElement,f=u.nodeName.toLowerCase();l?ne(l.value)?this._signalBasedValueAccessor=l:this._inputValueAccessor=l:this._inputValueAccessor=u,this._previousNativeValue=this.value,this.id=this.id,this._platform.IOS&&this._ngZone.runOutsideAngular(()=>{this._cleanupIosKeyup=this._renderer.listen(u,"keyup",this._iOSKeyupListener)}),this._errorStateTracker=new ge(i,this.ngControl,t,e,this.stateChanges),this._isServer=!this._platform.isBrowser,this._isNativeSelect=f==="select",this._isTextarea=f==="textarea",this._isInFormField=!!this._formField,this.disabledInteractive=this._config?.disabledInteractive||!1,this._isNativeSelect&&(this.controlType=u.multiple?"mat-native-select-multiple":"mat-native-select"),this._signalBasedValueAccessor&&We(()=>{this._signalBasedValueAccessor.value(),this.stateChanges.next()})}ngAfterViewInit(){this._platform.isBrowser&&this._autofillMonitor.monitor(this._elementRef.nativeElement).subscribe(e=>{this.autofilled=e.isAutofilled,this.stateChanges.next()})}ngOnChanges(){this.stateChanges.next()}ngOnDestroy(){this.stateChanges.complete(),this._platform.isBrowser&&this._autofillMonitor.stopMonitoring(this._elementRef.nativeElement),this._cleanupIosKeyup?.(),this._cleanupWebkitWheel?.()}ngDoCheck(){this.ngControl&&(this.updateErrorState(),this.ngControl.disabled!==null&&this.ngControl.disabled!==this.disabled&&(this.disabled=this.ngControl.disabled,this.stateChanges.next())),this._dirtyCheckNativeValue(),this._dirtyCheckPlaceholder()}focus(e){this._elementRef.nativeElement.focus(e)}updateErrorState(){this._errorStateTracker.updateErrorState()}_focusChanged(e){if(e!==this.focused){if(!this._isNativeSelect&&e&&this.disabled&&this.disabledInteractive){let t=this._elementRef.nativeElement;t.type==="number"?(t.type="text",t.setSelectionRange(0,0),t.type="number"):t.setSelectionRange(0,0)}this.focused=e,this.stateChanges.next()}}_onInput(){}_dirtyCheckNativeValue(){let e=this._elementRef.nativeElement.value;this._previousNativeValue!==e&&(this._previousNativeValue=e,this.stateChanges.next())}_dirtyCheckPlaceholder(){let e=this._getPlaceholder();if(e!==this._previousPlaceholder){let t=this._elementRef.nativeElement;this._previousPlaceholder=e,e?t.setAttribute("placeholder",e):t.removeAttribute("placeholder")}}_getPlaceholder(){return this.placeholder||null}_validateType(){ni.indexOf(this._type)>-1}_isNeverEmpty(){return this._neverEmptyInputTypes.indexOf(this._type)>-1}_isBadInput(){let e=this._elementRef.nativeElement.validity;return e&&e.badInput}get empty(){return!this._isNeverEmpty()&&!this._elementRef.nativeElement.value&&!this._isBadInput()&&!this.autofilled}get shouldLabelFloat(){if(this._isNativeSelect){let e=this._elementRef.nativeElement,t=e.options[0];return this.focused||e.multiple||!this.empty||!!(e.selectedIndex>-1&&t&&t.label)}else return this.focused&&!this.disabled||!this.empty}get describedByIds(){return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ")||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute("aria-describedby",e.join(" ")):t.removeAttribute("aria-describedby")}onContainerClick(){this.focused||this.focus()}_isInlineSelect(){let e=this._elementRef.nativeElement;return this._isNativeSelect&&(e.multiple||e.size>1)}_iOSKeyupListener=e=>{let t=e.target;!t.value&&t.selectionStart===0&&t.selectionEnd===0&&(t.setSelectionRange(1,1),t.setSelectionRange(0,0))};_getReadonlyAttribute(){return this._isNativeSelect?null:this.readonly||this.disabled&&this.disabledInteractive?"true":null}static \u0275fac=function(t){return new(t||n)};static \u0275dir=ie({type:n,selectors:[["input","matInput",""],["textarea","matInput",""],["select","matNativeControl",""],["input","matNativeControl",""],["textarea","matNativeControl",""]],hostAttrs:[1,"mat-mdc-input-element"],hostVars:21,hostBindings:function(t,i){t&1&&v("focus",function(){return i._focusChanged(!0)})("blur",function(){return i._focusChanged(!1)})("input",function(){return i._onInput()}),t&2&&(ae("id",i.id)("disabled",i.disabled&&!i.disabledInteractive)("required",i.required),F("name",i.name||null)("readonly",i._getReadonlyAttribute())("aria-disabled",i.disabled&&i.disabledInteractive?"true":null)("aria-invalid",i.empty&&i.required?null:i.errorState)("aria-required",i.required)("id",i.id),k("mat-input-server",i._isServer)("mat-mdc-form-field-textarea-control",i._isInFormField&&i._isTextarea)("mat-mdc-form-field-input-control",i._isInFormField)("mat-mdc-input-disabled-interactive",i.disabledInteractive)("mdc-text-field__input",i._isInFormField)("mat-mdc-native-select-inline",i._isInlineSelect()))},inputs:{disabled:"disabled",id:"id",placeholder:"placeholder",name:"name",required:"required",type:"type",errorStateMatcher:"errorStateMatcher",userAriaDescribedBy:[0,"aria-describedby","userAriaDescribedBy"],value:"value",readonly:"readonly",disabledInteractive:[2,"disabledInteractive","disabledInteractive",x]},exportAs:["matInput"],features:[Y([{provide:ve,useExisting:n}]),te]})}return n})(),Ht=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({imports:[z,z,Vt,A]})}return n})();var Z=class{_multiple;_emitChanges;compareWith;_selection=new Set;_deselectedToEmit=[];_selectedToEmit=[];_selected=null;get selected(){return this._selected||(this._selected=Array.from(this._selection.values())),this._selected}changed=new E;constructor(r=!1,e,t=!0,i){this._multiple=r,this._emitChanges=t,this.compareWith=i,e&&e.length&&(r?e.forEach(l=>this._markSelected(l)):this._markSelected(e[0]),this._selectedToEmit.length=0)}select(...r){this._verifyValueAssignment(r),r.forEach(t=>this._markSelected(t));let e=this._hasQueuedChanges();return this._emitChangeEvent(),e}deselect(...r){this._verifyValueAssignment(r),r.forEach(t=>this._unmarkSelected(t));let e=this._hasQueuedChanges();return this._emitChangeEvent(),e}setSelection(...r){this._verifyValueAssignment(r);let e=this.selected,t=new Set(r.map(l=>this._getConcreteValue(l)));r.forEach(l=>this._markSelected(l)),e.filter(l=>!t.has(this._getConcreteValue(l,t))).forEach(l=>this._unmarkSelected(l));let i=this._hasQueuedChanges();return this._emitChangeEvent(),i}toggle(r){return this.isSelected(r)?this.deselect(r):this.select(r)}clear(r=!0){this._unmarkAll();let e=this._hasQueuedChanges();return r&&this._emitChangeEvent(),e}isSelected(r){return this._selection.has(this._getConcreteValue(r))}isEmpty(){return this._selection.size===0}hasValue(){return!this.isEmpty()}sort(r){this._multiple&&this.selected&&this._selected.sort(r)}isMultipleSelection(){return this._multiple}_emitChangeEvent(){this._selected=null,(this._selectedToEmit.length||this._deselectedToEmit.length)&&(this.changed.next({source:this,added:this._selectedToEmit,removed:this._deselectedToEmit}),this._deselectedToEmit=[],this._selectedToEmit=[])}_markSelected(r){r=this._getConcreteValue(r),this.isSelected(r)||(this._multiple||this._unmarkAll(),this.isSelected(r)||this._selection.add(r),this._emitChanges&&this._selectedToEmit.push(r))}_unmarkSelected(r){r=this._getConcreteValue(r),this.isSelected(r)&&(this._selection.delete(r),this._emitChanges&&this._deselectedToEmit.push(r))}_unmarkAll(){this.isEmpty()||this._selection.forEach(r=>this._unmarkSelected(r))}_verifyValueAssignment(r){r.length>1&&this._multiple}_hasQueuedChanges(){return!!(this._deselectedToEmit.length||this._selectedToEmit.length)}_getConcreteValue(r,e){if(this.compareWith){e=e??this._selection;for(let t of e)if(this.compareWith(r,t))return t;return r}else return r}};var qt=(()=>{class n{_animationsDisabled=me();state="unchecked";disabled=!1;appearance="full";constructor(){}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=T({type:n,selectors:[["mat-pseudo-checkbox"]],hostAttrs:[1,"mat-pseudo-checkbox"],hostVars:12,hostBindings:function(t,i){t&2&&k("mat-pseudo-checkbox-indeterminate",i.state==="indeterminate")("mat-pseudo-checkbox-checked",i.state==="checked")("mat-pseudo-checkbox-disabled",i.disabled)("mat-pseudo-checkbox-minimal",i.appearance==="minimal")("mat-pseudo-checkbox-full",i.appearance==="full")("_mat-animation-noopable",i._animationsDisabled)},inputs:{state:"state",disabled:"disabled",appearance:"appearance"},decls:0,vars:0,template:function(t,i){},styles:[`.mat-pseudo-checkbox {
  border-radius: 2px;
  cursor: pointer;
  display: inline-block;
  vertical-align: middle;
  box-sizing: border-box;
  position: relative;
  flex-shrink: 0;
  transition: border-color 90ms cubic-bezier(0, 0, 0.2, 0.1), background-color 90ms cubic-bezier(0, 0, 0.2, 0.1);
}
.mat-pseudo-checkbox::after {
  position: absolute;
  opacity: 0;
  content: "";
  border-bottom: 2px solid currentColor;
  transition: opacity 90ms cubic-bezier(0, 0, 0.2, 0.1);
}
.mat-pseudo-checkbox._mat-animation-noopable {
  transition: none !important;
  animation: none !important;
}
.mat-pseudo-checkbox._mat-animation-noopable::after {
  transition: none;
}

.mat-pseudo-checkbox-disabled {
  cursor: default;
}

.mat-pseudo-checkbox-indeterminate::after {
  left: 1px;
  opacity: 1;
  border-radius: 2px;
}

.mat-pseudo-checkbox-checked::after {
  left: 1px;
  border-left: 2px solid currentColor;
  transform: rotate(-45deg);
  opacity: 1;
  box-sizing: content-box;
}

.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked::after, .mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate::after {
  color: var(--mat-pseudo-checkbox-minimal-selected-checkmark-color, var(--mat-sys-primary));
}
.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled::after, .mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled::after {
  color: var(--mat-pseudo-checkbox-minimal-disabled-selected-checkmark-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-pseudo-checkbox-full {
  border-color: var(--mat-pseudo-checkbox-full-unselected-icon-color, var(--mat-sys-on-surface-variant));
  border-width: 2px;
  border-style: solid;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-disabled {
  border-color: var(--mat-pseudo-checkbox-full-disabled-unselected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate {
  background-color: var(--mat-pseudo-checkbox-full-selected-icon-color, var(--mat-sys-primary));
  border-color: transparent;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked::after, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate::after {
  color: var(--mat-pseudo-checkbox-full-selected-checkmark-color, var(--mat-sys-on-primary));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled {
  background-color: var(--mat-pseudo-checkbox-full-disabled-selected-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked.mat-pseudo-checkbox-disabled::after, .mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate.mat-pseudo-checkbox-disabled::after {
  color: var(--mat-pseudo-checkbox-full-disabled-selected-checkmark-color, var(--mat-sys-surface));
}

.mat-pseudo-checkbox {
  width: 18px;
  height: 18px;
}

.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-checked::after {
  width: 14px;
  height: 6px;
  transform-origin: center;
  top: -4.2426406871px;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
}
.mat-pseudo-checkbox-minimal.mat-pseudo-checkbox-indeterminate::after {
  top: 8px;
  width: 16px;
}

.mat-pseudo-checkbox-full.mat-pseudo-checkbox-checked::after {
  width: 10px;
  height: 4px;
  transform-origin: center;
  top: -2.8284271247px;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
}
.mat-pseudo-checkbox-full.mat-pseudo-checkbox-indeterminate::after {
  top: 6px;
  width: 12px;
}
`],encapsulation:2,changeDetection:0})}return n})();var ri=["text"],li=[[["mat-icon"]],"*"],si=["mat-icon","*"];function ci(n,r){if(n&1&&y(0,"mat-pseudo-checkbox",1),n&2){let e=I();C("disabled",e.disabled)("state",e.selected?"checked":"unchecked")}}function di(n,r){if(n&1&&y(0,"mat-pseudo-checkbox",3),n&2){let e=I();C("disabled",e.disabled)}}function mi(n,r){if(n&1&&(a(0,"span",4),c(1),o()),n&2){let e=I();s(),le("(",e.group.label,")")}}var Fe=new w("MAT_OPTION_PARENT_COMPONENT"),De=new w("MatOptgroup");var Re=class{source;isUserInput;constructor(r,e=!1){this.source=r,this.isUserInput=e}},K=(()=>{class n{_element=h(B);_changeDetectorRef=h(se);_parent=h(Fe,{optional:!0});group=h(De,{optional:!0});_signalDisableRipple=!1;_selected=!1;_active=!1;_mostRecentViewValue="";get multiple(){return this._parent&&this._parent.multiple}get selected(){return this._selected}value;id=h(j).getId("mat-option-");get disabled(){return this.group&&this.group.disabled||this._disabled()}set disabled(e){this._disabled.set(e)}_disabled=ee(!1);get disableRipple(){return this._signalDisableRipple?this._parent.disableRipple():!!this._parent?.disableRipple}get hideSingleSelectionIndicator(){return!!(this._parent&&this._parent.hideSingleSelectionIndicator)}onSelectionChange=new V;_text;_stateChanges=new E;constructor(){let e=h(de);e.load(ut),e.load(st),this._signalDisableRipple=!!this._parent&&ne(this._parent.disableRipple)}get active(){return this._active}get viewValue(){return(this._text?.nativeElement.textContent||"").trim()}select(e=!0){this._selected||(this._selected=!0,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}deselect(e=!0){this._selected&&(this._selected=!1,this._changeDetectorRef.markForCheck(),e&&this._emitSelectionChangeEvent())}focus(e,t){let i=this._getHostElement();typeof i.focus=="function"&&i.focus(t)}setActiveStyles(){this._active||(this._active=!0,this._changeDetectorRef.markForCheck())}setInactiveStyles(){this._active&&(this._active=!1,this._changeDetectorRef.markForCheck())}getLabel(){return this.viewValue}_handleKeydown(e){(e.keyCode===13||e.keyCode===32)&&!U(e)&&(this._selectViaInteraction(),e.preventDefault())}_selectViaInteraction(){this.disabled||(this._selected=this.multiple?!this._selected:!0,this._changeDetectorRef.markForCheck(),this._emitSelectionChangeEvent(!0))}_getTabIndex(){return this.disabled?"-1":"0"}_getHostElement(){return this._element.nativeElement}ngAfterViewChecked(){if(this._selected){let e=this.viewValue;e!==this._mostRecentViewValue&&(this._mostRecentViewValue&&this._stateChanges.next(),this._mostRecentViewValue=e)}}ngOnDestroy(){this._stateChanges.complete()}_emitSelectionChangeEvent(e=!1){this.onSelectionChange.emit(new Re(this,e))}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=T({type:n,selectors:[["mat-option"]],viewQuery:function(t,i){if(t&1&&re(ri,7),t&2){let l;P(l=R())&&(i._text=l.first)}},hostAttrs:["role","option",1,"mat-mdc-option","mdc-list-item"],hostVars:11,hostBindings:function(t,i){t&1&&v("click",function(){return i._selectViaInteraction()})("keydown",function(u){return i._handleKeydown(u)}),t&2&&(ae("id",i.id),F("aria-selected",i.selected)("aria-disabled",i.disabled.toString()),k("mdc-list-item--selected",i.selected)("mat-mdc-option-multiple",i.multiple)("mat-mdc-option-active",i.active)("mdc-list-item--disabled",i.disabled))},inputs:{value:"value",id:"id",disabled:[2,"disabled","disabled",x]},outputs:{onSelectionChange:"onSelectionChange"},exportAs:["matOption"],ngContentSelectors:si,decls:8,vars:5,consts:[["text",""],["aria-hidden","true",1,"mat-mdc-option-pseudo-checkbox",3,"disabled","state"],[1,"mdc-list-item__primary-text"],["state","checked","aria-hidden","true","appearance","minimal",1,"mat-mdc-option-pseudo-checkbox",3,"disabled"],[1,"cdk-visually-hidden"],["aria-hidden","true","mat-ripple","",1,"mat-mdc-option-ripple","mat-focus-indicator",3,"matRippleTrigger","matRippleDisabled"]],template:function(t,i){t&1&&(oe(li),_(0,ci,1,2,"mat-pseudo-checkbox",1),q(1),a(2,"span",2,0),q(4,1),o(),_(5,di,1,1,"mat-pseudo-checkbox",3),_(6,mi,2,1,"span",4),y(7,"div",5)),t&2&&(b(i.multiple?0:-1),s(5),b(!i.multiple&&i.selected&&!i.hideSingleSelectionIndicator?5:-1),s(),b(i.group&&i.group._inert?6:-1),s(),C("matRippleTrigger",i._getHostElement())("matRippleDisabled",i.disabled||i.disableRipple))},dependencies:[qt,ht],styles:[`.mat-mdc-option {
  -webkit-user-select: none;
  user-select: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  display: flex;
  position: relative;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
  min-height: 48px;
  padding: 0 16px;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  color: var(--mat-option-label-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-option-label-text-font, var(--mat-sys-label-large-font));
  line-height: var(--mat-option-label-text-line-height, var(--mat-sys-label-large-line-height));
  font-size: var(--mat-option-label-text-size, var(--mat-sys-body-large-size));
  letter-spacing: var(--mat-option-label-text-tracking, var(--mat-sys-label-large-tracking));
  font-weight: var(--mat-option-label-text-weight, var(--mat-sys-body-large-weight));
}
.mat-mdc-option:hover:not(.mdc-list-item--disabled) {
  background-color: var(--mat-option-hover-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-hover-state-layer-opacity) * 100%), transparent));
}
.mat-mdc-option:focus.mdc-list-item, .mat-mdc-option.mat-mdc-option-active.mdc-list-item {
  background-color: var(--mat-option-focus-state-layer-color, color-mix(in srgb, var(--mat-sys-on-surface) calc(var(--mat-sys-focus-state-layer-opacity) * 100%), transparent));
  outline: 0;
}
.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) {
  background-color: var(--mat-option-selected-state-layer-color, var(--mat-sys-secondary-container));
}
.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled):not(.mat-mdc-option-active, .mat-mdc-option-multiple, :focus, :hover) .mdc-list-item__primary-text {
  color: var(--mat-option-selected-state-label-text-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-option .mat-pseudo-checkbox {
  --mat-pseudo-checkbox-minimal-selected-checkmark-color: var(--mat-option-selected-state-label-text-color, var(--mat-sys-on-secondary-container));
}
.mat-mdc-option.mdc-list-item {
  align-items: center;
  background: transparent;
}
.mat-mdc-option.mdc-list-item--disabled {
  cursor: default;
  pointer-events: none;
}
.mat-mdc-option.mdc-list-item--disabled .mat-mdc-option-pseudo-checkbox, .mat-mdc-option.mdc-list-item--disabled .mdc-list-item__primary-text, .mat-mdc-option.mdc-list-item--disabled > mat-icon {
  opacity: 0.38;
}
.mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 32px;
}
[dir=rtl] .mat-mdc-optgroup .mat-mdc-option:not(.mat-mdc-option-multiple) {
  padding-left: 16px;
  padding-right: 32px;
}
.mat-mdc-option .mat-icon,
.mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-icon,
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-full {
  margin-right: 0;
  margin-left: 16px;
}
.mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-left: 16px;
  flex-shrink: 0;
}
[dir=rtl] .mat-mdc-option .mat-pseudo-checkbox-minimal {
  margin-right: 16px;
  margin-left: 0;
}
.mat-mdc-option .mat-mdc-option-ripple {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  pointer-events: none;
}
.mat-mdc-option .mdc-list-item__primary-text {
  white-space: normal;
  font-size: inherit;
  font-weight: inherit;
  letter-spacing: inherit;
  line-height: inherit;
  font-family: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  margin-right: auto;
}
[dir=rtl] .mat-mdc-option .mdc-list-item__primary-text {
  margin-right: 0;
  margin-left: auto;
}
@media (forced-colors: active) {
  .mat-mdc-option.mdc-list-item--selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    content: "";
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 10px;
    height: 0;
    border-bottom: solid 10px;
    border-radius: 10px;
  }
  [dir=rtl] .mat-mdc-option.mdc-list-item--selected:not(:has(.mat-mdc-option-pseudo-checkbox))::after {
    right: auto;
    left: 16px;
  }
}

.mat-mdc-option-multiple {
  --mat-list-list-item-selected-container-color: var(--mat-list-list-item-container-color, transparent);
}

.mat-mdc-option-active .mat-focus-indicator::before {
  content: "";
}
`],encapsulation:2,changeDetection:0})}return n})();function Ut(n,r,e){if(e.length){let t=r.toArray(),i=e.toArray(),l=0;for(let u=0;u<n+1;u++)t[u].group&&t[u].group===i[l]&&l++;return l}return 0}function jt(n,r,e,t){return n<e?n:n+r>e+t?Math.max(0,n-t+r):e}var Gt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({imports:[A]})}return n})();var Ne=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({imports:[gt,Gt,K,A]})}return n})();var gi=["trigger"],_i=["panel"],bi=[[["mat-select-trigger"]],"*"],vi=["mat-select-trigger","*"];function yi(n,r){if(n&1&&(a(0,"span",4),c(1),o()),n&2){let e=I();s(),p(e.placeholder)}}function Ci(n,r){n&1&&q(0)}function xi(n,r){if(n&1&&(a(0,"span",11),c(1),o()),n&2){let e=I(2);s(),p(e.triggerValue)}}function Mi(n,r){if(n&1&&(a(0,"span",5),_(1,Ci,1,0)(2,xi,2,1,"span",11),o()),n&2){let e=I();s(),b(e.customTrigger?1:2)}}function Ei(n,r){if(n&1){let e=et();a(0,"div",12,1),v("keydown",function(i){je(e);let l=I();return Ge(l._handleKeydown(i))}),q(2,1),o()}if(n&2){let e=I();nt(e.panelClass),k("mat-select-panel-animations-enabled",!e._animationsDisabled)("mat-primary",(e._parentFormField==null?null:e._parentFormField.color)==="primary")("mat-accent",(e._parentFormField==null?null:e._parentFormField.color)==="accent")("mat-warn",(e._parentFormField==null?null:e._parentFormField.color)==="warn")("mat-undefined",!(e._parentFormField!=null&&e._parentFormField.color)),F("id",e.id+"-panel")("aria-multiselectable",e.multiple)("aria-label",e.ariaLabel||null)("aria-labelledby",e._getPanelAriaLabelledby())}}var Si=new w("mat-select-scroll-strategy",{providedIn:"root",factory:()=>{let n=h(Ke);return()=>Mt(n)}}),Oi=new w("MAT_SELECT_CONFIG"),ki=new w("MatSelectTrigger"),Le=class{source;value;constructor(r,e){this.source=r,this.value=e}},Yt=(()=>{class n{_viewportRuler=h(Ct);_changeDetectorRef=h(se);_elementRef=h(B);_dir=h(ft,{optional:!0});_idGenerator=h(j);_renderer=h(W);_parentFormField=h(ye,{optional:!0});ngControl=h(he,{self:!0,optional:!0});_liveAnnouncer=h(dt);_defaultOptions=h(Oi,{optional:!0});_animationsDisabled=me();_popoverLocation;_initialized=new E;_cleanupDetach;options;optionGroups;customTrigger;_positions=[{originX:"start",originY:"bottom",overlayX:"start",overlayY:"top"},{originX:"end",originY:"bottom",overlayX:"end",overlayY:"top"},{originX:"start",originY:"top",overlayX:"start",overlayY:"bottom",panelClass:"mat-mdc-select-panel-above"},{originX:"end",originY:"top",overlayX:"end",overlayY:"bottom",panelClass:"mat-mdc-select-panel-above"}];_scrollOptionIntoView(e){let t=this.options.toArray()[e];if(t){let i=this.panel.nativeElement,l=Ut(e,this.options,this.optionGroups),u=t._getHostElement();e===0&&l===1?i.scrollTop=0:i.scrollTop=jt(u.offsetTop,u.offsetHeight,i.scrollTop,i.offsetHeight)}}_positioningSettled(){this._scrollOptionIntoView(this._keyManager.activeItemIndex||0)}_getChangeEvent(e){return new Le(this,e)}_scrollStrategyFactory=h(Si);_panelOpen=!1;_compareWith=(e,t)=>e===t;_uid=this._idGenerator.getId("mat-select-");_triggerAriaLabelledBy=null;_previousControl;_destroy=new E;_errorStateTracker;stateChanges=new E;disableAutomaticLabeling=!0;userAriaDescribedBy;_selectionModel;_keyManager;_preferredOverlayOrigin;_overlayWidth;_onChange=()=>{};_onTouched=()=>{};_valueId=this._idGenerator.getId("mat-select-value-");_scrollStrategy;_overlayPanelClass=this._defaultOptions?.overlayPanelClass||"";get focused(){return this._focused||this._panelOpen}_focused=!1;controlType="mat-select";trigger;panel;_overlayDir;panelClass;disabled=!1;get disableRipple(){return this._disableRipple()}set disableRipple(e){this._disableRipple.set(e)}_disableRipple=ee(!1);tabIndex=0;get hideSingleSelectionIndicator(){return this._hideSingleSelectionIndicator}set hideSingleSelectionIndicator(e){this._hideSingleSelectionIndicator=e,this._syncParentProperties()}_hideSingleSelectionIndicator=this._defaultOptions?.hideSingleSelectionIndicator??!1;get placeholder(){return this._placeholder}set placeholder(e){this._placeholder=e,this.stateChanges.next()}_placeholder;get required(){return this._required??this.ngControl?.control?.hasValidator(M.required)??!1}set required(e){this._required=e,this.stateChanges.next()}_required;get multiple(){return this._multiple}set multiple(e){this._selectionModel,this._multiple=e}_multiple=!1;disableOptionCentering=this._defaultOptions?.disableOptionCentering??!1;get compareWith(){return this._compareWith}set compareWith(e){this._compareWith=e,this._selectionModel&&this._initializeSelection()}get value(){return this._value}set value(e){this._assignValue(e)&&this._onChange(e)}_value;ariaLabel="";ariaLabelledby;get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}typeaheadDebounceInterval;sortComparator;get id(){return this._id}set id(e){this._id=e||this._uid,this.stateChanges.next()}_id;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}panelWidth=this._defaultOptions&&typeof this._defaultOptions.panelWidth<"u"?this._defaultOptions.panelWidth:"auto";canSelectNullableOptions=this._defaultOptions?.canSelectNullableOptions??!1;optionSelectionChanges=He(()=>{let e=this.options;return e?e.changes.pipe(Se(e),Oe(()=>$(...e.map(t=>t.onSelectionChange)))):this._initialized.pipe(Oe(()=>this.optionSelectionChanges))});openedChange=new V;_openedStream=this.openedChange.pipe(Ee(e=>e),Me(()=>{}));_closedStream=this.openedChange.pipe(Ee(e=>!e),Me(()=>{}));selectionChange=new V;valueChange=new V;constructor(){let e=h(fe),t=h(ue,{optional:!0}),i=h(G,{optional:!0}),l=h(new at("tabindex"),{optional:!0}),u=h(Et,{optional:!0});this.ngControl&&(this.ngControl.valueAccessor=this),this._defaultOptions?.typeaheadDebounceInterval!=null&&(this.typeaheadDebounceInterval=this._defaultOptions.typeaheadDebounceInterval),this._errorStateTracker=new ge(e,this.ngControl,i,t,this.stateChanges),this._scrollStrategy=this._scrollStrategyFactory(),this.tabIndex=l==null?0:parseInt(l)||0,this._popoverLocation=u?.usePopover===!1?null:"inline",this.id=this.id}ngOnInit(){this._selectionModel=new Z(this.multiple),this.stateChanges.next(),this._viewportRuler.change().pipe(H(this._destroy)).subscribe(()=>{this.panelOpen&&(this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._changeDetectorRef.detectChanges())})}ngAfterContentInit(){this._initialized.next(),this._initialized.complete(),this._initKeyManager(),this._selectionModel.changed.pipe(H(this._destroy)).subscribe(e=>{e.added.forEach(t=>t.select()),e.removed.forEach(t=>t.deselect())}),this.options.changes.pipe(Se(null),H(this._destroy)).subscribe(()=>{this._resetOptions(),this._initializeSelection()})}ngDoCheck(){let e=this._getTriggerAriaLabelledby(),t=this.ngControl;if(e!==this._triggerAriaLabelledBy){let i=this._elementRef.nativeElement;this._triggerAriaLabelledBy=e,e?i.setAttribute("aria-labelledby",e):i.removeAttribute("aria-labelledby")}t&&(this._previousControl!==t.control&&(this._previousControl!==void 0&&t.disabled!==null&&t.disabled!==this.disabled&&(this.disabled=t.disabled),this._previousControl=t.control),this.updateErrorState())}ngOnChanges(e){(e.disabled||e.userAriaDescribedBy)&&this.stateChanges.next(),e.typeaheadDebounceInterval&&this._keyManager&&this._keyManager.withTypeAhead(this.typeaheadDebounceInterval),e.panelClass&&this.panelClass instanceof Set&&(this.panelClass=Array.from(this.panelClass))}ngOnDestroy(){this._cleanupDetach?.(),this._keyManager?.destroy(),this._destroy.next(),this._destroy.complete(),this.stateChanges.complete(),this._clearFromModal()}toggle(){this.panelOpen?this.close():this.open()}open(){this._canOpen()&&(this._parentFormField&&(this._preferredOverlayOrigin=this._parentFormField.getConnectedOverlayOrigin()),this._cleanupDetach?.(),this._overlayWidth=this._getOverlayWidth(this._preferredOverlayOrigin),this._applyModalPanelOwnership(),this._panelOpen=!0,this._overlayDir.positionChange.pipe(qe(1)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this._positioningSettled()}),this._overlayDir.attachOverlay(),this._keyManager.withHorizontalOrientation(null),this._highlightCorrectOption(),this._changeDetectorRef.markForCheck(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!0)))}_trackedModal=null;_applyModalPanelOwnership(){let e=this._elementRef.nativeElement.closest('body > .cdk-overlay-container [aria-modal="true"]');if(!e)return;let t=`${this.id}-panel`;this._trackedModal&&Te(this._trackedModal,"aria-owns",t),pt(e,"aria-owns",t),this._trackedModal=e}_clearFromModal(){if(!this._trackedModal)return;let e=`${this.id}-panel`;Te(this._trackedModal,"aria-owns",e),this._trackedModal=null}close(){this._panelOpen&&(this._panelOpen=!1,this._exitAndDetach(),this._keyManager.withHorizontalOrientation(this._isRtl()?"rtl":"ltr"),this._changeDetectorRef.markForCheck(),this._onTouched(),this.stateChanges.next(),Promise.resolve().then(()=>this.openedChange.emit(!1)))}_exitAndDetach(){if(this._animationsDisabled||!this.panel){this._detachOverlay();return}this._cleanupDetach?.(),this._cleanupDetach=()=>{t(),clearTimeout(i),this._cleanupDetach=void 0};let e=this.panel.nativeElement,t=this._renderer.listen(e,"animationend",l=>{l.animationName==="_mat-select-exit"&&(this._cleanupDetach?.(),this._detachOverlay())}),i=setTimeout(()=>{this._cleanupDetach?.(),this._detachOverlay()},200);e.classList.add("mat-select-panel-exit")}_detachOverlay(){this._overlayDir.detachOverlay(),this._changeDetectorRef.markForCheck()}writeValue(e){this._assignValue(e)}registerOnChange(e){this._onChange=e}registerOnTouched(e){this._onTouched=e}setDisabledState(e){this.disabled=e,this._changeDetectorRef.markForCheck(),this.stateChanges.next()}get panelOpen(){return this._panelOpen}get selected(){return this.multiple?this._selectionModel?.selected||[]:this._selectionModel?.selected[0]}get triggerValue(){if(this.empty)return"";if(this._multiple){let e=this._selectionModel.selected.map(t=>t.viewValue);return this._isRtl()&&e.reverse(),e.join(", ")}return this._selectionModel.selected[0].viewValue}updateErrorState(){this._errorStateTracker.updateErrorState()}_isRtl(){return this._dir?this._dir.value==="rtl":!1}_handleKeydown(e){this.disabled||(this.panelOpen?this._handleOpenKeydown(e):this._handleClosedKeydown(e))}_handleClosedKeydown(e){let t=e.keyCode,i=t===40||t===38||t===37||t===39,l=t===13||t===32,u=this._keyManager;if(!u.isTyping()&&l&&!U(e)||(this.multiple||e.altKey)&&i)e.preventDefault(),this.open();else if(!this.multiple){let f=this.selected;u.onKeydown(e);let g=this.selected;g&&f!==g&&this._liveAnnouncer.announce(g.viewValue,1e4)}}_handleOpenKeydown(e){let t=this._keyManager,i=e.keyCode,l=i===40||i===38,u=t.isTyping();if(l&&e.altKey)e.preventDefault(),this.close();else if(!u&&(i===13||i===32)&&t.activeItem&&!U(e))e.preventDefault(),t.activeItem._selectViaInteraction();else if(!u&&this._multiple&&i===65&&e.ctrlKey){e.preventDefault();let f=this.options.some(g=>!g.disabled&&!g.selected);this.options.forEach(g=>{g.disabled||(f?g.select():g.deselect())})}else{let f=t.activeItemIndex;t.onKeydown(e),this._multiple&&l&&e.shiftKey&&t.activeItem&&t.activeItemIndex!==f&&t.activeItem._selectViaInteraction()}}_handleOverlayKeydown(e){e.keyCode===27&&!U(e)&&(e.preventDefault(),this.close())}_onFocus(){this.disabled||(this._focused=!0,this.stateChanges.next())}_onBlur(){this._focused=!1,this._keyManager?.cancelTypeahead(),!this.disabled&&!this.panelOpen&&(this._onTouched(),this._changeDetectorRef.markForCheck(),this.stateChanges.next())}get empty(){return!this._selectionModel||this._selectionModel.isEmpty()}_initializeSelection(){Promise.resolve().then(()=>{this.ngControl&&(this._value=this.ngControl.value),this._setSelectionByValue(this._value),this.stateChanges.next()})}_setSelectionByValue(e){if(this.options.forEach(t=>t.setInactiveStyles()),this._selectionModel.clear(),this.multiple&&e)Array.isArray(e),e.forEach(t=>this._selectOptionByValue(t)),this._sortValues();else{let t=this._selectOptionByValue(e);t?this._keyManager.updateActiveItem(t):this.panelOpen||this._keyManager.updateActiveItem(-1)}this._changeDetectorRef.markForCheck()}_selectOptionByValue(e){let t=this.options.find(i=>{if(this._selectionModel.isSelected(i))return!1;try{return(i.value!=null||this.canSelectNullableOptions)&&this._compareWith(i.value,e)}catch{return!1}});return t&&this._selectionModel.select(t),t}_assignValue(e){return e!==this._value||this._multiple&&Array.isArray(e)?(this.options&&this._setSelectionByValue(e),this._value=e,!0):!1}_skipPredicate=e=>this.panelOpen?!1:e.disabled;_getOverlayWidth(e){return this.panelWidth==="auto"?(e instanceof Ae?e.elementRef:e||this._elementRef).nativeElement.getBoundingClientRect().width:this.panelWidth===null?"":this.panelWidth}_syncParentProperties(){if(this.options)for(let e of this.options)e._changeDetectorRef.markForCheck()}_initKeyManager(){this._keyManager=new mt(this.options).withTypeAhead(this.typeaheadDebounceInterval).withVerticalOrientation().withHorizontalOrientation(this._isRtl()?"rtl":"ltr").withHomeAndEnd().withPageUpDown().withAllowedModifierKeys(["shiftKey"]).skipPredicate(this._skipPredicate),this._keyManager.tabOut.subscribe(()=>{this.panelOpen&&(!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction(),this.focus(),this.close())}),this._keyManager.change.subscribe(()=>{this._panelOpen&&this.panel?this._scrollOptionIntoView(this._keyManager.activeItemIndex||0):!this._panelOpen&&!this.multiple&&this._keyManager.activeItem&&this._keyManager.activeItem._selectViaInteraction()})}_resetOptions(){let e=$(this.options.changes,this._destroy);this.optionSelectionChanges.pipe(H(e)).subscribe(t=>{this._onSelect(t.source,t.isUserInput),t.isUserInput&&!this.multiple&&this._panelOpen&&(this.close(),this.focus())}),$(...this.options.map(t=>t._stateChanges)).pipe(H(e)).subscribe(()=>{this._changeDetectorRef.detectChanges(),this.stateChanges.next()})}_onSelect(e,t){let i=this._selectionModel.isSelected(e);!this.canSelectNullableOptions&&e.value==null&&!this._multiple?(e.deselect(),this._selectionModel.clear(),this.value!=null&&this._propagateChanges(e.value)):(i!==e.selected&&(e.selected?this._selectionModel.select(e):this._selectionModel.deselect(e)),t&&this._keyManager.setActiveItem(e),this.multiple&&(this._sortValues(),t&&this.focus())),i!==this._selectionModel.isSelected(e)&&this._propagateChanges(),this.stateChanges.next()}_sortValues(){if(this.multiple){let e=this.options.toArray();this._selectionModel.sort((t,i)=>this.sortComparator?this.sortComparator(t,i,e):e.indexOf(t)-e.indexOf(i)),this.stateChanges.next()}}_propagateChanges(e){let t;this.multiple?t=this.selected.map(i=>i.value):t=this.selected?this.selected.value:e,this._value=t,this.valueChange.emit(t),this._onChange(t),this.selectionChange.emit(this._getChangeEvent(t)),this._changeDetectorRef.markForCheck()}_highlightCorrectOption(){if(this._keyManager)if(this.empty){let e=-1;for(let t=0;t<this.options.length;t++)if(!this.options.get(t).disabled){e=t;break}this._keyManager.setActiveItem(e)}else this._keyManager.setActiveItem(this._selectionModel.selected[0])}_canOpen(){return!this._panelOpen&&!this.disabled&&this.options?.length>0&&!!this._overlayDir}focus(e){this._elementRef.nativeElement.focus(e)}_getPanelAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||null,t=e?e+" ":"";return this.ariaLabelledby?t+this.ariaLabelledby:e}_getAriaActiveDescendant(){return this.panelOpen&&this._keyManager&&this._keyManager.activeItem?this._keyManager.activeItem.id:null}_getTriggerAriaLabelledby(){if(this.ariaLabel)return null;let e=this._parentFormField?.getLabelId()||"";return this.ariaLabelledby&&(e+=" "+this.ariaLabelledby),e||(e=this._valueId),e}get describedByIds(){return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ")||[]}setDescribedByIds(e){let t=this._elementRef.nativeElement;e.length?t.setAttribute("aria-describedby",e.join(" ")):t.removeAttribute("aria-describedby")}onContainerClick(e){let t=lt(e);t&&(t.tagName==="MAT-OPTION"||t.classList.contains("cdk-overlay-backdrop")||t.closest(".mat-mdc-select-panel"))||(this.focus(),this.open())}get shouldLabelFloat(){return this.panelOpen||!this.empty||this.focused&&!!this.placeholder}static \u0275fac=function(t){return new(t||n)};static \u0275cmp=T({type:n,selectors:[["mat-select"]],contentQueries:function(t,i,l){if(t&1&&tt(l,ki,5)(l,K,5)(l,De,5),t&2){let u;P(u=R())&&(i.customTrigger=u.first),P(u=R())&&(i.options=u),P(u=R())&&(i.optionGroups=u)}},viewQuery:function(t,i){if(t&1&&re(gi,5)(_i,5)(Pe,5),t&2){let l;P(l=R())&&(i.trigger=l.first),P(l=R())&&(i.panel=l.first),P(l=R())&&(i._overlayDir=l.first)}},hostAttrs:["role","combobox","aria-haspopup","listbox",1,"mat-mdc-select"],hostVars:21,hostBindings:function(t,i){t&1&&v("keydown",function(u){return i._handleKeydown(u)})("focus",function(){return i._onFocus()})("blur",function(){return i._onBlur()}),t&2&&(F("id",i.id)("tabindex",i.disabled?-1:i.tabIndex)("aria-controls",i.panelOpen?i.id+"-panel":null)("aria-expanded",i.panelOpen)("aria-label",i.ariaLabel||null)("aria-required",i.required.toString())("aria-disabled",i.disabled.toString())("aria-invalid",i.errorState)("aria-activedescendant",i._getAriaActiveDescendant()),k("mat-mdc-select-disabled",i.disabled)("mat-mdc-select-invalid",i.errorState)("mat-mdc-select-required",i.required)("mat-mdc-select-empty",i.empty)("mat-mdc-select-multiple",i.multiple)("mat-select-open",i.panelOpen))},inputs:{userAriaDescribedBy:[0,"aria-describedby","userAriaDescribedBy"],panelClass:"panelClass",disabled:[2,"disabled","disabled",x],disableRipple:[2,"disableRipple","disableRipple",x],tabIndex:[2,"tabIndex","tabIndex",e=>e==null?0:ke(e)],hideSingleSelectionIndicator:[2,"hideSingleSelectionIndicator","hideSingleSelectionIndicator",x],placeholder:"placeholder",required:[2,"required","required",x],multiple:[2,"multiple","multiple",x],disableOptionCentering:[2,"disableOptionCentering","disableOptionCentering",x],compareWith:"compareWith",value:"value",ariaLabel:[0,"aria-label","ariaLabel"],ariaLabelledby:[0,"aria-labelledby","ariaLabelledby"],errorStateMatcher:"errorStateMatcher",typeaheadDebounceInterval:[2,"typeaheadDebounceInterval","typeaheadDebounceInterval",ke],sortComparator:"sortComparator",id:"id",panelWidth:"panelWidth",canSelectNullableOptions:[2,"canSelectNullableOptions","canSelectNullableOptions",x]},outputs:{openedChange:"openedChange",_openedStream:"opened",_closedStream:"closed",selectionChange:"selectionChange",valueChange:"valueChange"},exportAs:["matSelect"],features:[Y([{provide:ve,useExisting:n},{provide:Fe,useExisting:n}]),te],ngContentSelectors:vi,decls:11,vars:10,consts:[["fallbackOverlayOrigin","cdkOverlayOrigin","trigger",""],["panel",""],["cdk-overlay-origin","",1,"mat-mdc-select-trigger",3,"click"],[1,"mat-mdc-select-value"],[1,"mat-mdc-select-placeholder","mat-mdc-select-min-line"],[1,"mat-mdc-select-value-text"],[1,"mat-mdc-select-arrow-wrapper"],[1,"mat-mdc-select-arrow"],["viewBox","0 0 24 24","width","24px","height","24px","focusable","false","aria-hidden","true"],["d","M7 10l5 5 5-5z"],["cdk-connected-overlay","","cdkConnectedOverlayHasBackdrop","","cdkConnectedOverlayBackdropClass","cdk-overlay-transparent-backdrop",3,"detach","backdropClick","overlayKeydown","cdkConnectedOverlayDisableClose","cdkConnectedOverlayPanelClass","cdkConnectedOverlayScrollStrategy","cdkConnectedOverlayOrigin","cdkConnectedOverlayPositions","cdkConnectedOverlayWidth","cdkConnectedOverlayFlexibleDimensions","cdkConnectedOverlayUsePopover"],[1,"mat-mdc-select-min-line"],["role","listbox","tabindex","-1",1,"mat-mdc-select-panel","mdc-menu-surface","mdc-menu-surface--open",3,"keydown"]],template:function(t,i){if(t&1&&(oe(bi),a(0,"div",2,0),v("click",function(){return i.open()}),a(3,"div",3),_(4,yi,2,1,"span",4)(5,Mi,3,1,"span",5),o(),a(6,"div",6)(7,"div",7),L(),a(8,"svg",8),y(9,"path",9),o()()()(),Ze(10,Ei,3,16,"ng-template",10),v("detach",function(){return i.close()})("backdropClick",function(){return i.close()})("overlayKeydown",function(u){return i._handleOverlayKeydown(u)})),t&2){let l=it(1);s(3),F("id",i._valueId),s(),b(i.empty?4:5),s(6),C("cdkConnectedOverlayDisableClose",!0)("cdkConnectedOverlayPanelClass",i._overlayPanelClass)("cdkConnectedOverlayScrollStrategy",i._scrollStrategy)("cdkConnectedOverlayOrigin",i._preferredOverlayOrigin||l)("cdkConnectedOverlayPositions",i._positions)("cdkConnectedOverlayWidth",i._overlayWidth)("cdkConnectedOverlayFlexibleDimensions",!0)("cdkConnectedOverlayUsePopover",i._popoverLocation)}},dependencies:[Ae,Pe],styles:[`@keyframes _mat-select-enter {
  from {
    opacity: 0;
    transform: scaleY(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes _mat-select-exit {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}
.mat-mdc-select {
  display: inline-block;
  width: 100%;
  outline: none;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  color: var(--mat-select-enabled-trigger-text-color, var(--mat-sys-on-surface));
  font-family: var(--mat-select-trigger-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-select-trigger-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-select-trigger-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-select-trigger-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-select-trigger-text-tracking, var(--mat-sys-body-large-tracking));
}

div.mat-mdc-select-panel {
  box-shadow: var(--mat-select-container-elevation-shadow, 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12));
}

.mat-mdc-select-disabled {
  color: var(--mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-select-disabled .mat-mdc-select-placeholder {
  color: var(--mat-select-disabled-trigger-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-select-trigger {
  display: inline-flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
  width: 100%;
}
.mat-mdc-select-disabled .mat-mdc-select-trigger {
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
}

.mat-mdc-select-value {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.mat-mdc-select-value-text {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.mat-mdc-select-arrow-wrapper {
  height: 24px;
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
}
.mat-form-field-appearance-fill .mdc-text-field--no-label .mat-mdc-select-arrow-wrapper {
  transform: none;
}

.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-invalid .mat-mdc-select-arrow,
.mat-form-field-invalid:not(.mat-form-field-disabled) .mat-mdc-form-field-infix::after {
  color: var(--mat-select-invalid-arrow-color, var(--mat-sys-error));
}

.mat-mdc-select-arrow {
  width: 10px;
  height: 5px;
  position: relative;
  color: var(--mat-select-enabled-arrow-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-form-field.mat-focused .mat-mdc-select-arrow {
  color: var(--mat-select-focused-arrow-color, var(--mat-sys-primary));
}
.mat-mdc-form-field .mat-mdc-select.mat-mdc-select-disabled .mat-mdc-select-arrow {
  color: var(--mat-select-disabled-arrow-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-select-open .mat-mdc-select-arrow {
  transform: rotate(180deg);
}
.mat-form-field-animations-enabled .mat-mdc-select-arrow {
  transition: transform 80ms linear;
}
.mat-mdc-select-arrow svg {
  fill: currentColor;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (forced-colors: active) {
  .mat-mdc-select-arrow svg {
    fill: CanvasText;
  }
  .mat-mdc-select-disabled .mat-mdc-select-arrow svg {
    fill: GrayText;
  }
}

div.mat-mdc-select-panel {
  width: 100%;
  max-height: 275px;
  outline: 0;
  overflow: auto;
  padding: 8px 0;
  box-sizing: border-box;
  transform-origin: top center;
  border-radius: 0 0 4px 4px;
  position: relative;
  background-color: var(--mat-select-panel-background-color, var(--mat-sys-surface-container));
}
.mat-mdc-select-panel-above div.mat-mdc-select-panel {
  border-radius: 4px 4px 0 0;
  transform-origin: bottom center;
}
@media (forced-colors: active) {
  div.mat-mdc-select-panel {
    outline: solid 1px;
  }
}

.mat-select-panel-animations-enabled {
  animation: _mat-select-enter 120ms cubic-bezier(0, 0, 0.2, 1);
}
.mat-select-panel-animations-enabled.mat-select-panel-exit {
  animation: _mat-select-exit 100ms linear;
}

.mat-mdc-select-placeholder {
  transition: color 400ms 133.3333333333ms cubic-bezier(0.25, 0.8, 0.25, 1);
  color: var(--mat-select-placeholder-text-color, var(--mat-sys-on-surface-variant));
}
.mat-mdc-form-field:not(.mat-form-field-animations-enabled) .mat-mdc-select-placeholder, ._mat-animation-noopable .mat-mdc-select-placeholder {
  transition: none;
}
.mat-form-field-hide-placeholder .mat-mdc-select-placeholder {
  color: transparent;
  -webkit-text-fill-color: transparent;
  transition: none;
  display: block;
}

.mat-mdc-form-field-type-mat-select:not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper {
  cursor: pointer;
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mat-mdc-floating-label {
  max-width: calc(100% - 18px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-fill .mdc-floating-label--float-above {
  max-width: calc(100% / 0.75 - 24px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-notched-outline__notch {
  max-width: calc(100% - 60px);
}
.mat-mdc-form-field-type-mat-select.mat-form-field-appearance-outline .mdc-text-field--label-floating .mdc-notched-outline__notch {
  max-width: calc(100% - 24px);
}

.mat-mdc-select-min-line:empty::before {
  content: " ";
  white-space: pre;
  width: 1px;
  display: inline-block;
  visibility: hidden;
}

.mat-form-field-appearance-fill .mat-mdc-select-arrow-wrapper {
  transform: var(--mat-select-arrow-transform, translateY(-8px));
}
`],encapsulation:2,changeDetection:0})}return n})();var Qt=(()=>{class n{static \u0275fac=function(t){return new(t||n)};static \u0275mod=O({type:n});static \u0275inj=S({imports:[St,Ne,A,xt,z,Ne]})}return n})();var Zt={production:!0,contactEndpoint:"/send-contact.php"};function Ti(n,r){n&1&&(a(0,"mat-error"),c(1),d(2,"translate"),o()),n&2&&(s(),p(m(2,1,"CONTACT.ERROR_REQUIRED")))}function Ii(n,r){n&1&&(a(0,"mat-error"),c(1),d(2,"translate"),o()),n&2&&(s(),p(m(2,1,"CONTACT.ERROR_RUC")))}function Ai(n,r){n&1&&(a(0,"mat-error"),c(1),d(2,"translate"),o()),n&2&&(s(),p(m(2,1,"CONTACT.ERROR_EMAIL")))}function Pi(n,r){n&1&&(a(0,"mat-error"),c(1),d(2,"translate"),o()),n&2&&(s(),p(m(2,1,"CONTACT.ERROR_PHONE")))}function Ri(n,r){if(n&1&&(a(0,"mat-option",17),c(1),o()),n&2){let e=r.$implicit;C("value",e),s(),p(e)}}function Fi(n,r){n&1&&(a(0,"mat-form-field",11)(1,"mat-label"),c(2),d(3,"translate"),o(),a(4,"mat-select",51)(5,"mat-option",52),c(6),d(7,"translate"),o(),a(8,"mat-option",53),c(9),d(10,"translate"),o(),a(11,"mat-option",54),c(12),d(13,"translate"),o(),a(14,"mat-option",55),c(15),d(16,"translate"),o(),a(17,"mat-option",56),c(18),d(19,"translate"),o(),a(20,"mat-option",57),c(21),d(22,"translate"),o(),a(23,"mat-option",58),c(24),d(25,"translate"),o(),a(26,"mat-option",59),c(27),d(28,"translate"),o(),a(29,"mat-option",60),c(30),d(31,"translate"),o(),a(32,"mat-option",61),c(33),d(34,"translate"),o(),a(35,"mat-option",62),c(36),d(37,"translate"),o(),a(38,"mat-option",63),c(39),d(40,"translate"),o(),a(41,"mat-option",64),c(42),d(43,"translate"),o()()()),n&2&&(s(2),p(m(3,14,"CONTACT.FIELD_SERVICE")),s(4),p(m(7,16,"CONTACT.SERVICE_PLC")),s(3),p(m(10,18,"CONTACT.SERVICE_TELEMETRY")),s(3),p(m(13,20,"CONTACT.SERVICE_SCADA")),s(3),p(m(16,22,"CONTACT.SERVICE_MAINTENANCE")),s(3),p(m(19,24,"CONTACT.SERVICE_PANELS")),s(3),p(m(22,26,"CONTACT.SERVICE_AI")),s(3),p(m(25,28,"CONTACT.SERVICE_AI_ML")),s(3),p(m(28,30,"CONTACT.SERVICE_CHLORINE_ML")),s(3),p(m(31,32,"CONTACT.SERVICE_TELEMETRY_CONTROL")),s(3),p(m(34,34,"CONTACT.SERVICE_REMOTE_VISION")),s(3),p(m(37,36,"CONTACT.SERVICE_VIDEO_INDUSTRIAL")),s(3),p(m(40,38,"CONTACT.SERVICE_MAPS_GEOLOCATION")),s(3),p(m(43,40,"CONTACT.SERVICE_AI_TOKENS")))}function Di(n,r){n&1&&(a(0,"mat-form-field",11)(1,"mat-label"),c(2),d(3,"translate"),o(),a(4,"mat-select",65)(5,"mat-option",66),c(6),d(7,"translate"),o(),a(8,"mat-option",67),c(9),d(10,"translate"),o(),a(11,"mat-option",68),c(12),d(13,"translate"),o(),a(14,"mat-option",69),c(15),d(16,"translate"),o(),a(17,"mat-option",70),c(18),d(19,"translate"),o(),a(20,"mat-option",71),c(21),d(22,"translate"),o(),a(23,"mat-option",72),c(24),d(25,"translate"),o(),a(26,"mat-option",73),c(27),d(28,"translate"),o(),a(29,"mat-option",74),c(30),d(31,"translate"),o(),a(32,"mat-option",75),c(33),d(34,"translate"),o(),a(35,"mat-option",76),c(36),d(37,"translate"),o(),a(38,"mat-option",77),c(39),d(40,"translate"),o()()()),n&2&&(s(2),p(m(3,13,"CONTACT.FIELD_PURCHASE_TYPE")),s(4),p(m(7,15,"CONTACT.PURCHASE_TELEMETRY")),s(3),p(m(10,17,"CONTACT.PURCHASE_PANELS")),s(3),p(m(13,19,"CONTACT.PURCHASE_SOFTWARE")),s(3),p(m(16,21,"CONTACT.PURCHASE_SENSORS")),s(3),p(m(19,23,"CONTACT.PURCHASE_DATALOGGER_GEO")),s(3),p(m(22,25,"CONTACT.PURCHASE_RTU_SAT")),s(3),p(m(25,27,"CONTACT.PURCHASE_RTU_LORA")),s(3),p(m(28,29,"CONTACT.PURCHASE_RTU_CEL")),s(3),p(m(31,31,"CONTACT.PURCHASE_PIEZOMETER")),s(3),p(m(34,33,"CONTACT.PURCHASE_STRAIN_GAUGE")),s(3),p(m(37,35,"CONTACT.PURCHASE_INCLINOMETER")),s(3),p(m(40,37,"CONTACT.PURCHASE_OTHER")))}function Ni(n,r){n&1&&(a(0,"div",28)(1,"mat-icon"),c(2,"check_circle"),o(),a(3,"span"),c(4),d(5,"translate"),o()()),n&2&&(s(4),p(m(5,1,"CONTACT.SUCCESS_MSG")))}function Li(n,r){n&1&&(a(0,"div",29)(1,"mat-icon"),c(2,"schedule"),o(),a(3,"span"),c(4,"Por favor espera un momento antes de volver a enviar el formulario."),o()())}var $t=class n{langService=h(Ot);fb=h(Ft);http=h(rt);submitted=!1;isSubmitting=!1;rateLimitError=!1;departments=["Lima","Callao","Amazonas","\xC1ncash","Apur\xEDmac","Arequipa","Ayacucho","Cajamarca","Cusco","Huancavelica","Hu\xE1nuco","Ica","Jun\xEDn","La Libertad","Lambayeque","Loreto","Madre de Dios","Moquegua","Pasco","Piura","Puno","San Mart\xEDn","Tacna","Tumbes","Ucayali"];contactForm=this.fb.group({razonSocial:["",M.required],ruc:["",[M.required,M.pattern(/^[0-9]{11}$/)]],email:["",[M.required,M.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)]],phone:["",[M.required,M.pattern(/^[0-9]{9}$/)]],department:["Lima",M.required],requirementType:["Servicio"],service:["Programaci\xF3n PLC"],purchaseType:["Equipos y Soluciones de Telemetr\xEDa"],message:[""]});setRequirementType(r){this.contactForm.get("requirementType")?.setValue(r)}onPhoneInput(r){let e=r.target,t=e.value.replace(/\D/g,"");t.length>9&&(t=t.slice(0,9)),e.value=t,this.contactForm.get("phone")?.setValue(t,{emitEvent:!1})}onRucInput(r){let e=r.target,t=e.value.replace(/\D/g,"");t.length>11&&(t=t.slice(0,11)),e.value=t,this.contactForm.get("ruc")?.setValue(t,{emitEvent:!1})}onPhoneKeydown(r){["Backspace","Tab","Delete","ArrowLeft","ArrowRight","Home","End","Enter"].includes(r.key)||r.ctrlKey||r.metaKey||/^[0-9]$/.test(r.key)||r.preventDefault()}onSubmit(){let r=this.contactForm.get("email")?.value||"";/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(r)||this.contactForm.get("email")?.setErrors({invalidEmail:!0});let t=this.contactForm.value.phone||"";(t.length!==9||!/^[0-9]{9}$/.test(t))&&this.contactForm.get("phone")?.setErrors({invalidLength:!0});let i=this.contactForm.get("ruc")?.value||"";if((i.length!==11||!/^[0-9]{11}$/.test(i))&&this.contactForm.get("ruc")?.setErrors({invalidLength:!0}),this.contactForm.invalid){this.contactForm.markAllAsTouched();return}this.isSubmitting=!0,this.submitted=!1,this.rateLimitError=!1;let l=this.contactForm.value.requirementType||"Servicio",u=l==="Servicio"?this.contactForm.value.service:this.contactForm.value.purchaseType,f={"Tipo de Cliente":"Empresa","Raz\xF3n Social":this.contactForm.value.razonSocial,RUC:this.contactForm.value.ruc,"Correo Corporativo":this.contactForm.value.email,Tel\u00E9fono:`+51 ${this.contactForm.value.phone}`,Ciudad:this.contactForm.value.department,Requerimiento:l,"Detalle Requerimiento":u||"","Mensaje Adicional":this.contactForm.value.message||"Sin mensaje adicional",_subject:"Nuevo contacto Empresa desde Enertronic: "+this.contactForm.value.razonSocial,_captcha:"false",_template:"table"};this.http.post(Zt.contactEndpoint,f).subscribe({next:()=>this.resetFormState(),error:g=>{this.isSubmitting=!1,g?.status===429?this.rateLimitError=!0:this.resetFormState()}})}resetFormState(){this.isSubmitting=!1,this.submitted=!0,this.contactForm.reset({department:"Lima",service:"Programaci\xF3n PLC",requirementType:"Servicio",purchaseType:"Equipos y Soluciones de Telemetr\xEDa"})}static \u0275fac=function(e){return new(e||n)};static \u0275cmp=T({type:n,selectors:[["app-contact"]],decls:140,vars:70,consts:[[1,"contact-page-wrapper"],[1,"map-container"],["src",Ye`https://maps.google.com/maps?q=ENERTRONIC+PERU+Las+Buganvilias+Ate+Lima&t=&z=18&ie=UTF8&iwloc=&output=embed`,"width","100%","height","380","allowfullscreen","","loading","lazy","referrerpolicy","no-referrer-when-downgrade","title","Ubicaci\xF3n Enertronic Per\xFA",1,"map-iframe",2,"border","0"],[1,"main-contact-container"],[1,"contact-card-grid"],[1,"contact-form-section"],[1,"form-header"],[1,"form-title"],[1,"form-subtitle"],[1,"contact-form",3,"ngSubmit","formGroup"],[1,"form-row"],["appearance","outline",1,"form-field"],["matInput","","formControlName","razonSocial",3,"placeholder"],["matInput","","type","text","formControlName","ruc","maxlength","11",3,"input","keydown","placeholder"],["matInput","","type","email","formControlName","email","placeholder","contacto@empresa.com"],["matInput","","type","tel","formControlName","phone","maxlength","9","placeholder","941 700 464",3,"input","keydown"],["formControlName","department"],[3,"value"],[1,"form-row","requirement-row"],[1,"requirement-type-container"],[1,"req-label"],[1,"req-toggle-group"],["type","button",1,"req-btn",3,"click"],[1,"form-full-row"],["appearance","outline",1,"form-field","full-width"],["matInput","","rows","3","formControlName","message",3,"placeholder"],[1,"form-action-row"],["mat-raised-button","","type","submit",1,"submit-btn",3,"disabled"],[1,"success-message"],[1,"rate-limit-message"],[1,"contact-info-sidebar"],[1,"info-item"],[1,"icon-circle"],[1,"info-content"],[1,"info-label"],["href","tel:+51941700464",1,"info-value"],[1,"icon-circle","whatsapp-icon-bg"],["href","https://api.whatsapp.com/send?phone=51941700464&text=Hola,%20deseo%20informaci\xF3n%20sobre%20uno%20de%20sus%20servicios","target","_blank","rel","noopener noreferrer",1,"info-value"],["href","mailto:ventas@enertronicperu.com",1,"info-value"],["href","mailto:proyectos@enertronicperu.com",1,"info-value"],[1,"info-value","text-wrap"],[1,"sidebar-social"],["href","https://www.facebook.com/profile.php?id=61595316304977","target","_blank","rel","noopener noreferrer","aria-label","Facebook",1,"social-circle","facebook"],["viewBox","0 0 24 24","width","18","height","18","fill","currentColor"],["d","M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H7.5v-3H10V9.5C10 7.01 11.49 5.6 13.79 5.6c1.1 0 2.25.2 2.25.2v2.48h-1.27c-1.24 0-1.63.77-1.63 1.56V12h2.78l-.45 3h-2.33v6.8c4.56-.93 8-4.96 8-9.8z"],["href","https://www.instagram.com/enertroniciotsac/?hl=es-la","target","_blank","rel","noopener noreferrer","aria-label","Instagram",1,"social-circle","instagram"],["d","M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"],["href","https://www.tiktok.com/@enertronic?lang=es-419","target","_blank","rel","noopener noreferrer","aria-label","TikTok",1,"social-circle","tiktok"],["d","M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.69a8.18 8.18 0 0 0 4.78 1.52V6.76a4.85 4.85 0 0 1-1.01-.07z"],["href","https://www.linkedin.com/in/enertronic-per\xFA-964219444","target","_blank","rel","noopener noreferrer","aria-label","LinkedIn",1,"social-circle","linkedin"],["d","M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"],["formControlName","service"],["value","Programaci\xF3n PLC"],["value","Telemetria"],["value","Software SCADA"],["value","Mantenimiento de plantas"],["value","Tableros instrumentales"],["value","Inteligencia artificial"],["value","Inteligencia artificial con machine learning"],["value","Dosificaci\xF3n de cloro para machine learning"],["value","Telemetr\xEDa / Telecontrol / Telemando"],["value","Visi\xF3n remota para sector miner\xEDa y maquinaria"],["value","Videovigilancia para procesos industriales cr\xEDticos"],["value","Servicio de plataforma de mapas y geolocalizaci\xF3n (APIs)"],["value","Servicio de tokens de procesamiento de inteligencia artificial para herramienta de apoyo a la toma de decisiones con IA"],["formControlName","purchaseType"],["value","Equipos y Soluciones de Telemetr\xEDa"],["value","Tableros de Instrumentaci\xF3n y Control"],["value","Licencias de Software SCADA"],["value","Sensores e Instrumentaci\xF3n Industrial"],["value","Data logger geot\xE9cnico"],["value","RTU Satelital"],["value","RTU LoRa"],["value","RTU Celular"],["value","Piez\xF3metros de cuerda vibrante"],["value","Strain gauge"],["value","Inclin\xF3metros IPI"],["value","Otros Productos / Equipos"]],template:function(e,t){if(e&1&&(a(0,"div",0)(1,"div",1),y(2,"iframe",2),o(),a(3,"div",3)(4,"div",4)(5,"div",5)(6,"div",6)(7,"h1",7),c(8),d(9,"translate"),o(),a(10,"p",8),c(11),d(12,"translate"),o()(),a(13,"form",9),v("ngSubmit",function(){return t.onSubmit()}),a(14,"div",10)(15,"mat-form-field",11)(16,"mat-label"),c(17),d(18,"translate"),o(),y(19,"input",12),d(20,"translate"),_(21,Ti,3,3,"mat-error"),o(),a(22,"mat-form-field",11)(23,"mat-label"),c(24),d(25,"translate"),o(),a(26,"input",13),d(27,"translate"),v("input",function(l){return t.onRucInput(l)})("keydown",function(l){return t.onPhoneKeydown(l)}),o(),_(28,Ii,3,3,"mat-error"),o()(),a(29,"div",10)(30,"mat-form-field",11)(31,"mat-label"),c(32),d(33,"translate"),o(),y(34,"input",14),_(35,Ai,3,3,"mat-error"),o(),a(36,"mat-form-field",11)(37,"mat-label"),c(38),d(39,"translate"),o(),a(40,"input",15),v("input",function(l){return t.onPhoneInput(l)})("keydown",function(l){return t.onPhoneKeydown(l)}),o(),_(41,Pi,3,3,"mat-error"),o()(),a(42,"div",10)(43,"mat-form-field",11)(44,"mat-label"),c(45),d(46,"translate"),o(),a(47,"mat-select",16),Xe(48,Ri,2,2,"mat-option",17,$e),o()()(),a(50,"div",18)(51,"div",19)(52,"label",20),c(53),d(54,"translate"),o(),a(55,"div",21)(56,"button",22),v("click",function(){return t.setRequirementType("Servicio")}),a(57,"mat-icon"),c(58,"build"),o(),a(59,"span"),c(60),d(61,"translate"),o()(),a(62,"button",22),v("click",function(){return t.setRequirementType("Compra")}),a(63,"mat-icon"),c(64,"shopping_cart"),o(),a(65,"span"),c(66),d(67,"translate"),o()()()(),_(68,Fi,44,42,"mat-form-field",11),_(69,Di,41,39,"mat-form-field",11),o(),a(70,"div",23)(71,"mat-form-field",24)(72,"mat-label"),c(73),d(74,"translate"),o(),y(75,"textarea",25),d(76,"translate"),o()(),a(77,"div",26)(78,"button",27)(79,"span"),c(80),d(81,"translate"),d(82,"translate"),o()()(),_(83,Ni,6,3,"div",28),_(84,Li,5,0,"div",29),o()(),a(85,"div",30)(86,"div",31)(87,"div",32)(88,"mat-icon"),c(89,"phone_iphone"),o()(),a(90,"div",33)(91,"h2",34),c(92),d(93,"translate"),o(),a(94,"a",35),c(95,"+51 941700464"),o()()(),a(96,"div",31)(97,"div",36)(98,"mat-icon"),c(99,"chat"),o()(),a(100,"div",33)(101,"h2",34),c(102,"Whatsapp:"),o(),a(103,"a",37),c(104,"+51 941700464"),o()()(),a(105,"div",31)(106,"div",32)(107,"mat-icon"),c(108,"email"),o()(),a(109,"div",33)(110,"h2",34),c(111),d(112,"translate"),o(),a(113,"a",38),c(114,"ventas@enertronicperu.com"),o(),a(115,"a",39),c(116,"proyectos@enertronicperu.com"),o()()(),a(117,"div",31)(118,"div",32)(119,"mat-icon"),c(120,"location_on"),o()(),a(121,"div",33)(122,"h2",34),c(123),d(124,"translate"),o(),a(125,"span",40),c(126,"Calle Buganvilias Mz.C Lte.26 Ate-Lima-Per\xFA"),o()()(),a(127,"div",41)(128,"a",42),L(),a(129,"svg",43),y(130,"path",44),o()(),X(),a(131,"a",45),L(),a(132,"svg",43),y(133,"path",46),o()(),X(),a(134,"a",47),L(),a(135,"svg",43),y(136,"path",48),o()(),X(),a(137,"a",49),L(),a(138,"svg",43),y(139,"path",50),o()()()()()()()),e&2){let i,l,u,f,g,N,Ve,Be;s(8),p(m(9,32,"CONTACT.PAGE_TITLE")),s(3),p(m(12,34,"CONTACT.PAGE_SUBTITLE")),s(2),C("formGroup",t.contactForm),s(4),p(m(18,36,"CONTACT.FIELD_COMPANY_NAME")),s(2),C("placeholder",m(20,38,"CONTACT.FIELD_COMPANY_NAME_PLACEHOLDER")),s(2),b((i=t.contactForm.get("razonSocial"))!=null&&i.invalid&&((i=t.contactForm.get("razonSocial"))!=null&&i.touched)?21:-1),s(3),p(m(25,40,"CONTACT.FIELD_RUC")),s(2),C("placeholder",m(27,42,"CONTACT.FIELD_RUC_PLACEHOLDER")),s(2),b((l=t.contactForm.get("ruc"))!=null&&l.invalid&&((l=t.contactForm.get("ruc"))!=null&&l.touched)?28:-1),s(4),p(m(33,44,"CONTACT.FIELD_CORP_EMAIL")),s(3),b((u=t.contactForm.get("email"))!=null&&u.invalid&&((u=t.contactForm.get("email"))!=null&&u.touched)?35:-1),s(3),p(m(39,46,"CONTACT.FIELD_PHONE")),s(3),b((f=t.contactForm.get("phone"))!=null&&f.invalid&&((f=t.contactForm.get("phone"))!=null&&f.touched)?41:-1),s(4),p(m(46,48,"CONTACT.FIELD_DEPARTMENT")),s(3),Je(t.departments),s(5),le("",m(54,50,"CONTACT.FIELD_REQUIREMENT"),":"),s(3),k("selected",((g=t.contactForm.get("requirementType"))==null?null:g.value)==="Servicio"),s(4),p(m(61,52,"CONTACT.REQ_SERVICE")),s(2),k("selected",((N=t.contactForm.get("requirementType"))==null?null:N.value)==="Compra"),s(4),p(m(67,54,"CONTACT.REQ_PURCHASE")),s(2),b(((Ve=t.contactForm.get("requirementType"))==null?null:Ve.value)==="Servicio"?68:-1),s(),b(((Be=t.contactForm.get("requirementType"))==null?null:Be.value)==="Compra"?69:-1),s(4),p(m(74,56,"CONTACT.FIELD_MESSAGE")),s(2),C("placeholder",m(76,58,"CONTACT.FIELD_MESSAGE_PLACEHOLDER")),s(3),C("disabled",t.isSubmitting),s(2),p(t.isSubmitting?m(81,60,"CONTACT.BTN_SENDING"):m(82,62,"CONTACT.BTN_SEND")),s(3),b(t.submitted?83:-1),s(),b(t.rateLimitError?84:-1),s(8),p(m(93,64,"CONTACT.INFO_PHONE")),s(19),p(m(112,66,"CONTACT.INFO_EMAIL")),s(12),p(m(124,68,"CONTACT.INFO_ADDRESS"))}},dependencies:[ot,yt,vt,bt,_t,Ht,zt,Q,_e,be,z,Qt,Yt,K,Dt,At,wt,Tt,It,Rt,Nt,G,Pt,kt],styles:[".contact-page-wrapper[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:2.5rem;width:100%;max-width:100vw;box-sizing:border-box;overflow-x:hidden}.map-container[_ngcontent-%COMP%]{width:100%;position:relative;overflow:hidden;border-bottom:1px solid var(--card-border, rgba(255, 255, 255, .08));box-shadow:0 10px 30px #00000026}.map-container[_ngcontent-%COMP%]   .map-iframe[_ngcontent-%COMP%]{display:block;width:100%;height:420px;filter:contrast(1.05)}@media(max-width:768px){.map-container[_ngcontent-%COMP%]   .map-iframe[_ngcontent-%COMP%]{height:300px}}@media(max-width:480px){.map-container[_ngcontent-%COMP%]   .map-iframe[_ngcontent-%COMP%]{height:240px}}.main-contact-container[_ngcontent-%COMP%]{max-width:1400px;margin:0 auto;padding:0 1.5rem 4rem;width:100%;box-sizing:border-box}@media(max-width:768px){.main-contact-container[_ngcontent-%COMP%]{padding:0 1.25rem 3rem}}@media(max-width:480px){.main-contact-container[_ngcontent-%COMP%]{padding:0 1rem 2rem}}@media(max-width:360px){.main-contact-container[_ngcontent-%COMP%]{padding:0 .75rem 1.5rem}}.contact-card-grid[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 340px;gap:3rem;align-items:flex-start;width:100%;box-sizing:border-box}@media(max-width:960px){.contact-card-grid[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr);gap:2.5rem}}.contact-form-section[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1.75rem;width:100%;min-width:0;max-width:100%;box-sizing:border-box}.form-header[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.35rem}.form-header[_ngcontent-%COMP%]   .form-title[_ngcontent-%COMP%]{font-size:1.75rem;font-weight:900;color:var(--text-primary, #ffffff);margin:0;letter-spacing:.5px;text-transform:uppercase}@media(max-width:600px){.form-header[_ngcontent-%COMP%]   .form-title[_ngcontent-%COMP%]{font-size:1.35rem}}.form-header[_ngcontent-%COMP%]   .form-subtitle[_ngcontent-%COMP%]{font-size:1.05rem;font-weight:600;color:var(--text-secondary, #94a3b8);margin:0}@media(max-width:600px){.form-header[_ngcontent-%COMP%]   .form-subtitle[_ngcontent-%COMP%]{font-size:.92rem}}.client-type-switcher[_ngcontent-%COMP%]{display:flex;gap:.5rem;background:#0f172a99;padding:.35rem;border-radius:12px;border:1px solid var(--card-border, rgba(255, 255, 255, .1));width:fit-content}@media(max-width:540px){.client-type-switcher[_ngcontent-%COMP%]{width:100%}}.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:.5rem;padding:.6rem 1.25rem;border-radius:8px;border:none;background:transparent;color:var(--text-secondary, #94a3b8);font-size:.95rem;font-weight:700;cursor:pointer;transition:all .2s ease}@media(max-width:540px){.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]{flex:1;font-size:.88rem;padding:.55rem .65rem}}@media(max-width:360px){.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]{font-size:.82rem;gap:.3rem}}.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:20px;width:20px;height:20px}@media(max-width:360px){.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px}}.client-type-switcher[_ngcontent-%COMP%]   .type-tab[_ngcontent-%COMP%]:hover{color:var(--text-primary, #ffffff);background:#ffffff0d}.client-type-switcher[_ngcontent-%COMP%]   .type-tab.active[_ngcontent-%COMP%]{background:#0284c7;color:#fff;box-shadow:0 4px 14px #0284c759}.contact-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1.25rem;width:100%;max-width:100%;box-sizing:border-box}.requirement-row[_ngcontent-%COMP%]{align-items:center}.requirement-type-container[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.4rem;width:100%;max-width:100%;box-sizing:border-box}.requirement-type-container[_ngcontent-%COMP%]   .req-label[_ngcontent-%COMP%]{font-size:.85rem;font-weight:700;color:var(--text-secondary, #94a3b8);text-transform:uppercase;letter-spacing:.5px}.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]{display:flex;gap:.5rem;width:100%;max-width:100%;box-sizing:border-box}@media(max-width:480px){.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]{width:100%}}.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]   .req-btn[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;gap:.4rem;padding:.65rem 1rem;border-radius:8px;border:1px solid var(--card-border, rgba(255, 255, 255, .15));background:#ffffff08;color:var(--text-secondary, #94a3b8);font-size:.9rem;font-weight:600;cursor:pointer;transition:all .2s ease;box-sizing:border-box}@media(max-width:480px){.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]   .req-btn[_ngcontent-%COMP%]{flex:1;min-width:0;padding:.55rem .5rem;font-size:.85rem}}.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]   .req-btn[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:18px;width:18px;height:18px}.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]   .req-btn[_ngcontent-%COMP%]:hover{border-color:#ea580c;color:#fff}.requirement-type-container[_ngcontent-%COMP%]   .req-toggle-group[_ngcontent-%COMP%]   .req-btn.selected[_ngcontent-%COMP%]{background:#ea580c26;border-color:#ea580c;color:#ea580c;font-weight:700}.form-row[_ngcontent-%COMP%]{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;width:100%;max-width:100%;box-sizing:border-box}@media(max-width:640px){.form-row[_ngcontent-%COMP%]{grid-template-columns:minmax(0,1fr);gap:.85rem}}.form-full-row[_ngcontent-%COMP%]{width:100%;max-width:100%;min-width:0;box-sizing:border-box}.form-field[_ngcontent-%COMP%]{width:100%;max-width:100%;min-width:0;display:block;box-sizing:border-box}.form-field[_ngcontent-%COMP%]     .mat-mdc-text-field-wrapper{width:100%!important;max-width:100%!important;box-sizing:border-box!important}.form-field[_ngcontent-%COMP%]   .mat-mdc-form-field-subscript-wrapper[_ngcontent-%COMP%]{padding:0 4px;box-sizing:border-box}.form-field[_ngcontent-%COMP%]   mat-error[_ngcontent-%COMP%]{font-size:.78rem;font-weight:600;color:#ef4444}.form-action-row[_ngcontent-%COMP%]{margin-top:.5rem}.submit-btn[_ngcontent-%COMP%]{background:#ea580c!important;color:#fff!important;font-weight:700!important;letter-spacing:.5px;padding:0 2rem!important;height:46px!important;border-radius:8px!important;box-shadow:none!important;transition:background .2s ease,transform .15s ease!important}@media(max-width:480px){.submit-btn[_ngcontent-%COMP%]{width:100%;height:48px!important}}.submit-btn[_ngcontent-%COMP%]:hover{background:#c2410c!important;transform:translateY(-1px)}.success-message[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;padding:1rem 1.25rem;border-radius:12px;background:#10b9811f;border:1px solid rgba(16,185,129,.3);color:#10b981;font-size:.92rem;font-weight:600;margin-top:.5rem}.success-message[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:22px;width:22px;height:22px}.rate-limit-message[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;padding:1rem 1.25rem;border-radius:12px;background:#f59e0b1f;border:1px solid rgba(245,158,11,.3);color:#f59e0b;font-size:.92rem;font-weight:600;margin-top:.5rem}.rate-limit-message[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:22px;width:22px;height:22px}.contact-info-sidebar[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:1.75rem;padding-top:.5rem}@media(max-width:960px){.contact-info-sidebar[_ngcontent-%COMP%]{border-top:1px solid var(--card-border, rgba(255, 255, 255, .08));padding-top:2rem}}@media(max-width:380px){.contact-info-sidebar[_ngcontent-%COMP%]{gap:1.25rem;padding-top:1.5rem}}.info-item[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:1rem}.icon-circle[_ngcontent-%COMP%]{width:44px;height:44px;border-radius:12px;background:#38bdf81f;border:1px solid rgba(56,189,248,.25);display:flex;align-items:center;justify-content:center;color:#38bdf8;flex-shrink:0}.icon-circle.whatsapp-icon-bg[_ngcontent-%COMP%]{background:#25d3661f;border-color:#25d3664d;color:#25d366}.icon-circle[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{font-size:24px;width:24px;height:24px}.info-content[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:.2rem}.info-label[_ngcontent-%COMP%]{font-size:1.05rem;font-weight:800;color:#ea580c;margin:0;letter-spacing:.3px}.info-value[_ngcontent-%COMP%]{font-size:.98rem;font-weight:600;color:var(--text-primary, #e2e8f0);text-decoration:none;transition:color .2s ease;word-break:break-word;overflow-wrap:anywhere}.info-value[_ngcontent-%COMP%]:hover{color:#38bdf8}.info-value.text-wrap[_ngcontent-%COMP%]{line-height:1.45}.sidebar-social[_ngcontent-%COMP%]{display:flex;align-items:center;gap:.75rem;margin-top:.5rem}.sidebar-social[_ngcontent-%COMP%]   .social-circle[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;width:38px;height:38px;border-radius:50%;background:#ffffff0f;border:1px solid rgba(255,255,255,.15);color:#cbd5e1;transition:all .25s ease;text-decoration:none}.sidebar-social[_ngcontent-%COMP%]   .social-circle.facebook[_ngcontent-%COMP%]{color:#1877f2;border-color:#1877f24d}.sidebar-social[_ngcontent-%COMP%]   .social-circle.facebook[_ngcontent-%COMP%]:hover{background:#1877f2;color:#fff;border-color:#1877f2;transform:translateY(-2px);box-shadow:0 4px 14px #1877f273}.sidebar-social[_ngcontent-%COMP%]   .social-circle.youtube[_ngcontent-%COMP%]{color:red;border-color:#ff00004d}.sidebar-social[_ngcontent-%COMP%]   .social-circle.youtube[_ngcontent-%COMP%]:hover{background:red;color:#fff;border-color:red;transform:translateY(-2px);box-shadow:0 4px 14px #ff000073}.sidebar-social[_ngcontent-%COMP%]   .social-circle.instagram[_ngcontent-%COMP%]{color:#e1306c;border-color:#e1306c4d}.sidebar-social[_ngcontent-%COMP%]   .social-circle.instagram[_ngcontent-%COMP%]:hover{background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);color:#fff;border-color:#e1306c;transform:translateY(-2px);box-shadow:0 4px 14px #e1306c73}.sidebar-social[_ngcontent-%COMP%]   .social-circle.tiktok[_ngcontent-%COMP%]{color:#fff;border-color:#fff3}.sidebar-social[_ngcontent-%COMP%]   .social-circle.tiktok[_ngcontent-%COMP%]:hover{background:#010101;color:#69c9d0;border-color:#69c9d0;transform:translateY(-2px);box-shadow:0 4px 14px #69c9d073}.sidebar-social[_ngcontent-%COMP%]   .social-circle.linkedin[_ngcontent-%COMP%]{color:#0a66c2;border-color:#0a66c24d}.sidebar-social[_ngcontent-%COMP%]   .social-circle.linkedin[_ngcontent-%COMP%]:hover{background:#0a66c2;color:#fff;border-color:#0a66c2;transform:translateY(-2px);box-shadow:0 4px 14px #0a66c273}"]})};export{$t as ContactComponent};
